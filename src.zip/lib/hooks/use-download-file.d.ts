type RequestFunction = () => Promise<Response>;
interface UseDownloadFileProps {
    requestFunction: RequestFunction;
    name?: string;
}
export declare const useDownloadFile: ({ requestFunction, name, }: UseDownloadFileProps) => {
    downloadFile: () => Promise<void>;
    isPending: boolean;
};
export {};
