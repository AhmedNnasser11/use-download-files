/// <reference types="react" />
export declare const useExportImage: () => {
    exportElement: (filename?: string) => Promise<void>;
    elementRef: import("react").MutableRefObject<HTMLDivElement | null>;
};
